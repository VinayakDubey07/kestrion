"""
The execution engine. This is the part that makes "production-grade" true
rather than aspirational: every step is checkpointed, every run is
resumable, every tool call that mutates external state can be gated on
human approval.

Worked example used in comments throughout: a kubectl agent that (1) reads
cluster state, (2) proposes a YAML change, (3) requires human approval,
(4) applies it, (5) verifies rollout. This mirrors the bastion-host kubectl
MCP agent you already built — the approval gate is exactly the kind of
thing that's awkward to retrofit into LangGraph but trivial if it's in the
engine's core loop from day one.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Callable, Literal, Mapping

from .secrets import SecretProvider, EnvVarSecretProvider
from .types import (
    AgentState,
    Checkpoint,
    CheckpointStore,
    Event,
    EventType,
    Node,
    RunStatus,
    TelemetryProvider,
    Tool,
    ToolResult,
    new_id,
    utcnow,
)

from .errors import (
    ApprovalRequired,
    CheckpointNotFoundError,
    HandoffCompleted,
    InvalidRunStatusError,
    InvalidToolApprovalError,
    InvalidToolInputError,
    InputRequired,
    RunExpiredError,
)

logger = logging.getLogger("kestrion.engine")


class Engine:
    """
    Drives a graph of Nodes to completion, persisting an event log and
    periodic checkpoints. Stateless across runs by design — you can run
    many Engine instances behind a load balancer, because all durable
    state lives in the CheckpointStore, not in this object.
    """

    def __init__(
        self,
        nodes: Mapping[str, Node],
        tools: Mapping[str, Tool],
        store: CheckpointStore,
        entry_node: str,
        approval_callback: Callable[[str, dict], bool] | None = None,
        max_steps: int = 100,
        secrets: SecretProvider | None = None,
        telemetry: TelemetryProvider | None = None,
    ):
        self.nodes = nodes
        self.tools = tools
        self.store = store
        self.entry_node = entry_node
        self.max_steps = max_steps
        self.secrets = secrets or EnvVarSecretProvider()
        self.telemetry = telemetry
        # sync hook the host app can override; default = auto-deny.
        # In production this is what a UI "approve kubectl apply" button
        # calls into, or a Slack approval workflow, etc.
        self.approval_callback = approval_callback or (lambda *_: False)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def start(self, run_id: str | None = None, **initial_scratch) -> AgentState:
        run_id = run_id or new_id("run")
        state = AgentState(run_id=run_id, status=RunStatus.RUNNING, current_node=self.entry_node)
        state.scratch.update(initial_scratch)

        await self._emit(state, EventType.RUN_STARTED, {"entry_node": self.entry_node})
        return await self._drive(state)

    async def resume(
        self, run_id: str, on_expired: Literal["status", "raise"] = "status"
    ) -> AgentState:
        """
        Crash recovery / human-approval resume in one code path. Load the
        latest checkpoint, replay any events since it (in case the process
        died between checkpoint and completion), then keep driving.

        on_expired controls what happens if this run's pending approval
        deadline (set via ToolSpec.approval_timeout_seconds) has passed
        without all required roles approving:
          - "status" (default): the run transitions to RunStatus.EXPIRED
            and is returned normally — consistent with how every other
            terminal state (COMPLETED, FAILED) already works in this
            codebase: callers check .status, no exception needed for the
            common case.
          - "raise": raises RunExpiredError instead. For callers who want
            a hard failure if they accidentally try to resume something
            stale — e.g. a cron job that should alert loudly rather than
            silently return a status nobody checks.
        """
        checkpoint = await self.store.latest(run_id)
        if checkpoint is None:
            raise CheckpointNotFoundError(run_id)

        state = checkpoint.state
        newer_events = await self.store.events_since(run_id, checkpoint.event_seq)
        for evt in newer_events:
            self._fold(state, evt)

        if state.status == RunStatus.WAITING_ON_HUMAN:
            pending = state.scratch.get("_pending_approval") or {}
            expires_at = pending.get("expires_at")
            if expires_at is not None and datetime.fromisoformat(expires_at) < utcnow():
                state.status = RunStatus.EXPIRED
                await self._emit(
                    state,
                    EventType.RUN_EXPIRED,
                    {"tool": pending.get("tool"), "expired_at": expires_at},
                )
                await self._checkpoint(state)
                if on_expired == "raise":
                    raise RunExpiredError(run_id, pending.get("tool", "<unknown>"), expires_at)
                return state
            state.status = RunStatus.RUNNING

        return await self._drive(state)

    async def fork(self, run_id: str, at_seq: int, new_run_id: str | None = None) -> str:
        """
        Create a new run that is an exact clone of `run_id` up to the
        specified event count (`at_seq`). Returns the new run ID.
        """
        new_run_id = new_run_id or new_id(f"{run_id}_fork")
        
        fork_events = await self.store.events_up_to(run_id, at_seq)
        
        if not fork_events:
            raise ValueError(f"No events found for run {run_id!r} to fork at sequence {at_seq}")

        # The first event MUST be RUN_STARTED, which contains the entry_node.
        first_event = fork_events[0]
        if first_event.type != EventType.RUN_STARTED:
            raise ValueError(f"First event of run {run_id!r} is not RUN_STARTED")
            
        entry_node = first_event.payload.get("entry_node", self.entry_node)
        
        # Build the new state from scratch
        state = AgentState(run_id=new_run_id, status=RunStatus.RUNNING, current_node=entry_node)
        
        for evt in fork_events:
            # Clone the event for the new run_id
            cloned_evt = Event(
                event_id=new_id("evt"),
                run_id=new_run_id,
                type=evt.type,
                timestamp=evt.timestamp,
                payload=evt.payload,
                node=evt.node,
                tokens_in=evt.tokens_in,
                tokens_out=evt.tokens_out,
                cost_usd=evt.cost_usd,
            )
            seq = await self.store.append_event(cloned_evt)
            state.last_event_seq = seq
            self._fold(state, cloned_evt)
            
            # Since we are folding all events up to at_seq, if there are RUN_COMPLETED,
            # FAILED, EXPIRED, STATE_TRANSITION, or HUMAN_INTERVENTION events, we need to correctly mirror
            # the status. _fold doesn't update status, so we manually do it here based on the log.
            if cloned_evt.type == EventType.RUN_COMPLETED:
                state.status = RunStatus.COMPLETED
                state.current_node = None
            elif cloned_evt.type == EventType.RUN_FAILED:
                state.status = RunStatus.FAILED
            elif cloned_evt.type == EventType.RUN_EXPIRED:
                state.status = RunStatus.EXPIRED
            elif cloned_evt.type == EventType.STATE_TRANSITION:
                state.current_node = cloned_evt.payload.get("to")
            elif cloned_evt.type == EventType.HUMAN_INTERVENTION:
                reason = cloned_evt.payload.get("reason")
                if reason in ("approval_required", "input_required"):
                    state.status = RunStatus.WAITING_ON_HUMAN
                elif reason in ("approval_granted", "input_provided"):
                    state.status = RunStatus.RUNNING
                    
        # Persist the forked checkpoint
        await self._checkpoint(state)
        return new_run_id

    async def approve_pending_tool(
        self,
        run_id: str,
        tool: str | None = None,
        role: str = "__any__",
    ) -> AgentState:
        """
        Record approval for the pending tool on a paused run and persist it
        durably. The caller is responsible for calling ``resume()`` separately
        (unlike ``Agent.approve()`` which wraps both steps).

        Designed for raw Engine users who manage the run loop themselves
        rather than going through the ``Agent`` wrapper. For the high-level
        one-call API, use ``Agent.approve()`` instead.

        Parameters
        ----------
        run_id:
            Run ID currently in ``WAITING_ON_HUMAN`` status.
        tool:
            Name of the tool to approve. Defaults to the pending tool in
            ``state.scratch["_pending_approval"]["tool"]``.
        role:
            Role granting the approval. Defaults to ``"__any__"``.

        Returns
        -------
        The updated ``AgentState`` with the approval recorded. Call
        ``engine.resume(run_id)`` after this to continue the run.
        """
        checkpoint = await self.store.latest(run_id)
        if checkpoint is None:
            raise CheckpointNotFoundError(run_id)

        state = checkpoint.state

        if state.status != RunStatus.WAITING_ON_HUMAN:
            raise InvalidRunStatusError(
                run_id,
                state.status.value,
                [RunStatus.WAITING_ON_HUMAN.value]
            )

        if "_pending_input" in state.scratch and state.scratch["_pending_input"].get("tool"):
            raise InvalidToolApprovalError(
                f"Run {run_id!r} is waiting for human input, not approval. Use provide_input()."
            )

        pending = state.scratch.get("_pending_approval") or {}
        pending_tool = pending.get("tool")
        if tool is None:
            if pending_tool is None:
                raise InvalidToolApprovalError(
                    f"Run {run_id!r} has no pending tool in scratch. "
                    "Pass tool= explicitly."
                )
            tool = pending_tool
        elif pending_tool is not None and tool != pending_tool:
            raise InvalidToolApprovalError(
                f"Tool {tool!r} does not match the pending tool "
                f"{pending_tool!r} for run {run_id!r}."
            )

        self.record_approval(state, tool, role=role)

        approval_event = Event.create(
            run_id=run_id,
            type=EventType.HUMAN_INTERVENTION,
            payload={"reason": "approval_granted", "tool": tool, "role": role},
            node=state.current_node,
        )
        seq = await self.store.append_event(approval_event)
        state.last_event_seq = seq

        await self._checkpoint(state)
        return state

    async def provide_input(self, run_id: str, text: str, tool: str | None = None) -> AgentState:
        """
        Provide human input for a paused run.

        Parameters
        ----------
        run_id:
            Run ID currently in ``WAITING_ON_HUMAN`` status.
        text:
            The input string from the human to inject into the tool call.
        tool:
            Name of the tool awaiting input. Defaults to the pending tool in
            ``state.scratch["_pending_input"]["tool"]``.

        Returns
        -------
        The updated ``AgentState``. Call ``engine.resume(run_id)`` after this.
        """
        checkpoint = await self.store.latest(run_id)
        if checkpoint is None:
            raise CheckpointNotFoundError(run_id)

        state = checkpoint.state

        if state.status != RunStatus.WAITING_ON_HUMAN:
            raise InvalidRunStatusError(
                run_id,
                state.status.value,
                [RunStatus.WAITING_ON_HUMAN.value]
            )

        if "_pending_approval" in state.scratch and state.scratch["_pending_approval"].get("tool"):
            raise InvalidToolInputError(
                f"Run {run_id!r} is waiting for approval, not input. Use approve_tool()."
            )

        pending = state.scratch.get("_pending_input") or {}
        pending_tool = pending.get("tool")
        if tool is None:
            if pending_tool is None:
                raise InvalidToolInputError(
                    f"Run {run_id!r} has no pending input request. Pass tool= explicitly."
                )
            tool = pending_tool
        elif pending_tool is not None and tool != pending_tool:
            raise InvalidToolInputError(
                f"Tool {tool!r} does not match the pending tool {pending_tool!r} for run {run_id!r}."
            )

        if not text:
            raise InvalidToolInputError(f"Run {run_id!r} input for tool {tool!r} cannot be empty.")

        import hashlib
        question = pending.get("question")
        key = hashlib.md5(question.encode(), usedforsecurity=False).hexdigest() if question else tool

        # Record the input (with idempotent guard)
        inputs = state.scratch.setdefault("_human_inputs", {})
        if key in inputs:
            logger.warning(f"Run {run_id!r} already has input for this request. Overwriting.")
        inputs[key] = text

        input_event = Event.create(
            run_id=run_id,
            type=EventType.HUMAN_INTERVENTION,
            payload={"reason": "input_provided", "tool": tool, "text": text},
            node=state.current_node,
        )
        seq = await self.store.append_event(input_event)
        state.last_event_seq = seq

        await self._checkpoint(state)
        return state

    @staticmethod
    def record_approval(state: AgentState, tool_name: str, role: str = "__any__") -> None:
        """
        Correctly appends a role to state.scratch["_approved_tools"][tool_name]
        without clobbering any roles already recorded there. This exists
        specifically to replace the error-prone pattern of hand-writing
        scratch["_approved_tools"] = {tool: True} — that overwrite pattern
        silently destroys a partially-satisfied approval chain (e.g. if
        "engineer" already approved and you then overwrite the whole dict
        to record "manager" approving, the engineer's approval vanishes).

        Caller is still responsible for persisting a checkpoint (via
        save() against the store) after calling this and before calling
        resume() — this only mutates the in-memory AgentState, consistent
        with every other state-mutating helper in this module.
        """
        approved = state.scratch.setdefault("_approved_tools", {})
        existing = approved.get(tool_name)
        if existing is True:
            # Already fully approved under the old bool shape; nothing to add.
            return
        roles = set(existing) if isinstance(existing, list) else set()
        roles.add(role)
        approved[tool_name] = list(roles)

    # ------------------------------------------------------------------
    # Internal: the actual graph-walking loop
    # ------------------------------------------------------------------

    async def _drive(self, state: AgentState) -> AgentState:
        step_count = 0
        while state.status == RunStatus.RUNNING and state.current_node is not None:
            if step_count >= self.max_steps:
                raise RuntimeError(
                    f"Run {state.run_id!r} exceeded maximum engine steps ({self.max_steps}). "
                    "Infinite loop protection triggered."
                )
            step_count += 1
            
            node = self.nodes[state.current_node]

            try:
                result = await node.run(state)
            except ApprovalRequired as approval:
                # This is the key production behavior: we don't block a
                # thread waiting for a human. We checkpoint and return
                # control. Some other process/request resumes us later.
                state.status = RunStatus.WAITING_ON_HUMAN

                # The deadline is set ONCE, the first time approval is
                # requested for this tool — not reset on every retry (e.g.
                # a partial chain still missing one role re-raises this
                # same exception on each resume() attempt). Re-deriving
                # "first requested at" from any existing pending-approval
                # record for this exact tool is what makes that correct.
                existing_pending = state.scratch.get("_pending_approval")
                if existing_pending and existing_pending.get("tool") == approval.tool_name:
                    requested_at = existing_pending.get("requested_at", utcnow().isoformat())
                else:
                    requested_at = utcnow().isoformat()

                tool_spec = self.tools[approval.tool_name].spec
                expires_at = None
                if tool_spec.approval_timeout_seconds is not None:
                    requested_dt = datetime.fromisoformat(requested_at)
                    expires_at = (
                        requested_dt + timedelta(seconds=tool_spec.approval_timeout_seconds)
                    ).isoformat()

                state.scratch["_pending_approval"] = {
                    "tool": approval.tool_name,
                    "kwargs": approval.kwargs,
                    "resume_node": state.current_node,
                    "missing_roles": approval.missing_roles,
                    "requested_at": requested_at,
                    "expires_at": expires_at,
                }
                await self._emit(
                    state,
                    EventType.HUMAN_INTERVENTION,
                    {
                        "reason": "approval_required",
                        "tool": approval.tool_name,
                        "missing_roles": approval.missing_roles,
                        "expires_at": expires_at,
                    },
                )
                await self._checkpoint(state)
                return state

            except InputRequired as input_req:
                state.status = RunStatus.WAITING_ON_HUMAN
                state.scratch["_pending_input"] = {
                    "tool": input_req.tool_name,
                    "question": input_req.question,
                    "resume_node": state.current_node,
                }
                await self._emit(
                    state,
                    EventType.HUMAN_INTERVENTION,
                    {
                        "reason": "input_required",
                        "tool": input_req.tool_name,
                        "question": input_req.question,
                    },
                )
                await self._checkpoint(state)
                return state
            except Exception as exc:
                state.status = RunStatus.FAILED
                await self._emit(state, EventType.RUN_FAILED, {"error": str(exc)})
                await self._checkpoint(state)
                raise

            # Fold this node's events into state, then advance.
            for evt in result.events:
                seq = await self.store.append_event(evt)
                state.last_event_seq = seq
                self._fold(state, evt)
            state.scratch.update(result.state_updates)

            if result.next_node is None:
                state.status = RunStatus.COMPLETED
                state.current_node = None
                await self._emit(state, EventType.RUN_COMPLETED, {})
            else:
                await self._emit(
                    state,
                    EventType.STATE_TRANSITION,
                    {"from": node.name, "to": result.next_node},
                )
                state.current_node = result.next_node

            # Checkpoint every transition. For high-frequency graphs you'd
            # make this configurable (e.g. every N steps) — but the
            # *default* should be safe, not fast.
            await self._checkpoint(state)

        return state

    def check_approval(self, state: AgentState, tool_name: str, kwargs: dict) -> None:
        """
        Raises ApprovalRequired if `tool_name` has unsatisfied required
        roles, otherwise returns normally. This is the SAME check
        call_tool performs internally before executing a tool — exposed
        publicly so callers like Agent's parallel-tool-call dispatch can
        pre-check an entire batch of calls for approval before running
        ANY of them, without duplicating this logic (and risking it
        silently drifting out of sync the next time approval-gating
        changes, which has already happened twice in this codebase).
        """
        tool = self.tools[tool_name]
        required_roles = tool.spec.required_roles()
        if not required_roles:
            return
        recorded = state.scratch.get("_approved_tools", {}).get(tool_name)
        # Backward-compat shape: scratch["_approved_tools"][name] = True
        # (from before chains existed) means "approved, role-agnostic" —
        # treat it as satisfying any/all required roles. Must check this
        # BEFORE trying to treat `recorded` as an iterable of role names,
        # since True is not iterable (caught by the regression test
        # this exact bug produced — test_resume_from_independent_engine
        # _after_approval and others, which all pre-date the chain
        # feature and store the bool shape).
        if recorded is True:
            approved_roles = set(required_roles)
        elif isinstance(recorded, list):
            approved_roles = set(recorded)
        else:
            approved_roles = set()
        missing = [r for r in required_roles if r not in approved_roles]
        if missing:
            raise ApprovalRequired(tool_name, kwargs, missing_roles=missing)

    async def call_tool(self, state: AgentState, tool_name: str, **kwargs) -> ToolResult:
        """
        Nodes call tools through the engine, never directly — this is the
        single choke point where approval-gating and event emission for
        tool calls happens, so individual nodes can't accidentally bypass
        the safety gate for a mutating kubectl/SQL call.
        """
        self.check_approval(state, tool_name, kwargs)
        tool = self.tools[tool_name]

        # Emit original args, not including _state or _secrets
        await self._emit(state, EventType.TOOL_CALL_STARTED, {"tool": tool_name, "args": kwargs})
        kwargs["_state"] = state
        kwargs["_secrets"] = self.secrets
        try:
            result = await tool.call(**kwargs)
        except ApprovalRequired as exc:
            # A tool's OWN call() can raise this directly — the
            # motivating case is SubAgentTool, where a sub-agent's run
            # pausing for approval needs to propagate to the parent as a
            # pause, not get logged as a tool failure. Re-raise as-is,
            # but clean injected internal objects out of kwargs so they don't break JSON serialization.
            exc.kwargs.pop("_state", None)
            exc.kwargs.pop("_secrets", None)
            raise
        except Exception as exc:
            if isinstance(exc, (HandoffCompleted, InputRequired)):
                # Same reasoning as ApprovalRequired above — a successful
                # handoff or input request is not a tool failure. Since these are in
                # core/errors.py, we can safely check isinstance here directly.
                raise
            await self._emit(state, EventType.TOOL_CALL_FAILED, {"tool": tool_name, "error": str(exc)})
            raise
        await self._emit(
            state,
            EventType.TOOL_CALL_COMPLETED,
            {"tool": tool_name, "output": str(result.output)[:2000]},
        )
        return result

    async def record_event(self, state: AgentState, event: Event) -> None:
        """
        Public escape hatch for nodes that need to durably record
        something that isn't a tool call — the motivating case is
        Agent's LLM-loop node recording LLM_CALL_COMPLETED events (for
        token/cost tracking) as they happen, rather than batching them
        into the eventual NodeResult. Batching would lose them if the
        node later raises ApprovalRequired and never returns a
        NodeResult at all. Appends to the store AND folds into state
        immediately — same durability guarantee as call_tool's internal
        _emit calls.
        """
        seq = await self.store.append_event(event)
        state.last_event_seq = seq
        if self.telemetry:
            import asyncio
            asyncio.create_task(self.telemetry.on_event(event))
        self._fold(state, event)

    # ------------------------------------------------------------------
    # Event sourcing plumbing
    # ------------------------------------------------------------------

    async def _emit(self, state: AgentState, type: EventType, payload: dict) -> Event:
        evt = Event.create(run_id=state.run_id, type=type, payload=payload, node=state.current_node)
        seq = await self.store.append_event(evt)
        state.last_event_seq = seq
        if self.telemetry:
            # We don't await this directly to avoid blocking the engine's core loop
            # on external I/O (like an OTel exporter sending over the network).
            import asyncio
            asyncio.create_task(self.telemetry.on_event(evt))
        return evt

    def _fold(self, state: AgentState, evt: Event) -> None:
        """
        The fold function: Event -> AgentState mutation. This is the ONLY
        place state changes happen as a result of an event. Keeping this
        centralized is what makes replay/debugging tractable — you can
        rebuild any historical state by replaying events through this
        one function.
        """
        if evt.type == EventType.TOOL_CALL_COMPLETED:
            state.history.append({"type": "tool_result", **evt.payload})
        elif evt.type == EventType.LLM_CALL_COMPLETED:
            state.history.append({"type": "llm_response", **evt.payload})
            state.total_tokens += evt.tokens_in + evt.tokens_out
            state.total_cost_usd += evt.cost_usd
        elif evt.type == EventType.CONTEXT_COMPACTED:
            summary_text = evt.payload.get("summary", "")
            state.history = [{"type": "summary", "content": summary_text}]

    async def _checkpoint(self, state: AgentState) -> Checkpoint:
        checkpoint = Checkpoint(
            checkpoint_id=new_id("ckpt"),
            run_id=state.run_id,
            state=state,
            created_at=utcnow(),
            event_seq=state.last_event_seq,
        )
        await self.store.save(checkpoint)
        await self._emit(state, EventType.CHECKPOINT_SAVED, {"checkpoint_id": checkpoint.checkpoint_id})
        return checkpoint