"""
@tool turns a plain Python function into something satisfying the
Tool/ToolSpec contract from core/types.py, by introspecting the
function signature into a JSON schema. This is the highest-risk piece
of Phase 2, flagged as such in the build plan — type hints have a lot
of edge cases (Optional, defaults, list[str], nested types). What's
implemented here covers the common cases; anything genuinely exotic
(Pydantic models, deeply nested generics) is a known gap, not silently
mishandled — see the NotImplementedError below.
"""

from __future__ import annotations

import functools
import inspect
import re
import time
from typing import Any, Callable, Union, get_args, get_origin, get_type_hints

from kestrion.core.types import Tool, ToolResult, ToolSpec

_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def _python_type_to_json_schema(annotation: Any) -> dict[str, Any]:
    """
    Best-effort conversion of a type annotation to a JSON schema
    fragment. Handles: plain types, Optional[X] (-> X's schema, since
    JSON schema has no first-class None), list[X], and falls back to
    "string" for anything unrecognized rather than crashing — an LLM
    can usually work with an under-specified schema, but a hard crash
    at decoration time would break the whole tool registration.
    """
    origin = get_origin(annotation)

    if origin is Union:
        args = [a for a in get_args(annotation) if a is not type(None)]
        if len(args) == 1:
            return _python_type_to_json_schema(args[0])
        return {"type": "string"}  # multi-type unions: punt to string, documented gap

    if origin in (list, tuple):
        item_args = get_args(annotation)
        item_schema = _python_type_to_json_schema(item_args[0]) if item_args else {"type": "string"}
        return {"type": "array", "items": item_schema}

    if origin is dict:
        return {"type": "object"}

    if annotation in _TYPE_MAP:
        return {"type": _TYPE_MAP[annotation]}

    if annotation is inspect.Parameter.empty:
        # No type hint at all — still allow the tool to be registered,
        # but the schema is maximally permissive rather than guessed.
        return {"type": "string"}

    # Unrecognized annotation (e.g. a Pydantic model, a custom class).
    # Rather than silently producing a wrong/misleading schema, this is
    # the explicit gap mentioned above.
    raise NotImplementedError(
        f"@tool cannot auto-generate a JSON schema for annotation {annotation!r}. "
        f"Supported: str, int, float, bool, list[T], dict, and Optional[T] of these."
    )


def _parse_docstring_params(doc: str | None) -> dict[str, str]:
    if not doc:
        return {}

    params = {}
    lines = doc.split("\n")

    in_args_section = False
    current_param = None

    for line in lines:
        stripped = line.strip()

        if stripped in ("Args:", "Arguments:", "Parameters:"):
            in_args_section = True
            continue

        if in_args_section and stripped == "":
            continue
        if in_args_section and re.match(r'^[A-Z][a-zA-Z]+:', stripped):
            in_args_section = False

        sphinx_match = re.match(r':param\s+(?:[\w\[\]|]+\s+)?(\w+)\s*:\s*(.*)', stripped)
        if sphinx_match:
            current_param = sphinx_match.group(1)
            params[current_param] = sphinx_match.group(2).strip()
            continue

        if in_args_section:
            google_match = re.match(r'^(\w+)\s*(?:\([^)]+\))?\s*:\s*(.*)', stripped)
            if google_match:
                current_param = google_match.group(1)
                params[current_param] = google_match.group(2).strip()
                continue

        if (
            current_param
            and stripped
            and not sphinx_match
            and not re.match(r'^(\w+)\s*(?:\([^)]+\))?\s*:', stripped)
            and not stripped.startswith(":")
        ):
            params[current_param] += " " + stripped

    return params


def _build_parameters_schema(func: Callable) -> dict[str, Any]:
    sig = inspect.signature(func)
    type_hints = get_type_hints(func)
    param_docs = _parse_docstring_params(func.__doc__)
    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        if name == "self" or name.startswith("_"):
            continue
        annotation = type_hints.get(name, param.annotation)
        prop_schema = _python_type_to_json_schema(annotation)
        if name in param_docs:
            prop_schema["description"] = param_docs[name]
        
        properties[name] = prop_schema
        if param.default is inspect.Parameter.empty:
            required.append(name)
        else:
            properties[name]["default"] = param.default

    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required
    return schema


class _FunctionTool(Tool):
    """Wraps a plain function (sync or async) to satisfy the Tool interface."""

    def __init__(self, func: Callable, spec: ToolSpec):
        self._func = func
        self._is_async = inspect.iscoroutinefunction(func) or inspect.iscoroutinefunction(getattr(func, '__func__', None))
        self.spec = spec
        self._sig_params = set(inspect.signature(func).parameters.keys())

    def __get__(self, instance, owner=None) -> _FunctionTool:
        if instance is None:
            return self
        import types
        bound_func = types.MethodType(self._func, instance) if not isinstance(self._func, types.MethodType) else self._func
        bound_tool = _FunctionTool(bound_func, self.spec)
        functools.update_wrapper(bound_tool, bound_func)  # type: ignore[arg-type]
        return bound_tool

    def __call__(self, *args, **kwargs):
        return self._func(*args, **kwargs)

    async def call(self, **kwargs) -> ToolResult:
        # Filter out injected kwargs (like _state) that this function doesn't expect
        filtered_kwargs = {k: v for k, v in kwargs.items() if k in self._sig_params}
        start = time.monotonic()
        try:
            if self._is_async:
                output = await self._func(**filtered_kwargs)
            else:
                output = self._func(**filtered_kwargs)
            return ToolResult(
                tool_name=self.spec.name,
                output=output,
                duration_ms=(time.monotonic() - start) * 1000,
            )
        except Exception as exc:
            # Re-raise control-flow exceptions that the engine relies on
            from kestrion.core.errors import InputRequired, HandoffCompleted
            if isinstance(exc, (InputRequired, HandoffCompleted)):
                raise
            return ToolResult(
                tool_name=self.spec.name,
                output=None,
                error=str(exc),
                duration_ms=(time.monotonic() - start) * 1000,
            )


def tool(
    func: Callable | None = None,
    *,
    requires_approval: bool | str | list[str] = False,
    approval_timeout_seconds: float | None = None,
    name: str | None = None,
):
    """
    Decorator that turns a function into a Kestrion Tool.

    Usage:
        @tool
        def get_cluster_state() -> dict:
            '''Read current deployment replica counts.'''
            ...

        @tool(requires_approval=True)
        def apply_manifest(yaml: str) -> dict:
            '''kubectl apply a manifest against the cluster.'''
            ...

        @tool(requires_approval=["engineer", "manager"])
        def deploy_to_prod() -> dict:
            '''Deploys to production. Needs both an engineer and a manager.'''
            ...

        @tool(requires_approval=True, approval_timeout_seconds=3600.0)
        def restart_service() -> dict:
            '''Restarts a service. Must be approved within an hour.'''
            ...

    The docstring becomes the tool description the LLM sees — make it
    descriptive, since it's the only thing the model has to decide
    whether/how to call the tool.

    NOTE: requires_approval accepting a role string or list of roles
    (approval chains), and approval_timeout_seconds, were both added to
    ToolSpec when those features were built, but this decorator's
    signature was never updated to pass them through — meaning anyone
    using @tool(requires_approval=["a", "b"]) before this fix hit a
    TypeError, since the decorator only accepted a bare bool. Found
    while building an integration demo that actually exercised every
    feature together through @tool, rather than constructing ToolSpec
    directly the way every unit test for chains/timeouts had done.
    """

    def decorator(f: Callable) -> _FunctionTool:
        tool_name = name or f.__name__
        description = (f.__doc__ or "").strip() or f"Calls {tool_name}"
        parameters = _build_parameters_schema(f)

        spec = ToolSpec(
            name=tool_name,
            description=description,
            parameters=parameters,
            requires_approval=requires_approval,
            approval_timeout_seconds=approval_timeout_seconds,
        )

        wrapped = _FunctionTool(f, spec)
        functools.update_wrapper(wrapped, f)  # type: ignore[arg-type]
        return wrapped

    if func is not None:
        # Bare @tool usage (no parens, no kwargs)
        return decorator(func)
    return decorator